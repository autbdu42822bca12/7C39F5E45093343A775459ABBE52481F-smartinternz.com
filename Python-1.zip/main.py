n=int(input("Enter a year:"))
if n%4==0:
  print(n,"is a leap year")
else:
  print(n,"is a not leap year")